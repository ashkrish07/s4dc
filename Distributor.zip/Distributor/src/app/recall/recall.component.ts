import { Component, OnInit } from '@angular/core';
import { ApiService } from '../api-service.service';

@Component({
  selector: 'app-recall',
  templateUrl: './recall.component.html',
  styleUrls: ['./recall.component.css']
})
export class RecallComponent implements OnInit {

  manualInput:boolean=true;
  recallItems = [];
  constructor() { }

  ngOnInit() {
  }

  toggleTab(event)
  {
    if(event.tabTitle == "Auto Recall")
      this.automatedInputFn();
    else
      this.manualInputFn();
  }
  manualInputFn()
  {
    this.manualInput = true;   
  }

  automatedInputFn()
  {
    this.manualInput = false;
    this.recallItems = [{'asserid':'LOT1','source':'IOT'}, {'asserid':'LOT2','source':'IOT'}, {'asserid':'LOT3','source':'IOT'}, {'asserid':'LOT4','source':'Date'},{'asserid':'LOT5','source':'Date'},{'asserid':'LOT6','source':'IOT'},{'asserid':'LOT7','source':'Date'},{'asserid':'LOT8','source':'IOT'}];
  }

}
