import { Component, OnInit } from '@angular/core';
import { FormGroup,FormControl } from '@angular/forms';
import { FormBuilder } from'@angular/forms';
import { Router,ActivatedRoute } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ApiService } from '../api-service.service';

@Component({
  selector: 'app-warehouse',
  templateUrl: './warehouse.component.html',
  styleUrls: ['./warehouse.component.css']
})
export class WarehouseComponent implements OnInit {

  userName:string;
  searchText1:string;
  searchText2:string;
  Lotid: any;
  userid: any;
  AssetId: any;
  useridin: any;
  AssetIdin: any;
  certid:any;
  Targetid:any;
  Status:any;
  modal:any;
  NgbdModalContent:any;
  hideAlert:boolean=true;
  myGroup:FormGroup;
  inbound:boolean=false;
  outbound:boolean=true;
  inboundAccept=true;
  inboundReject=true;
  moredetails:boolean=true;
  assetCreated:boolean=true;
  assetTransferred:boolean=true;
  packingdate: any;
  useby: any;
  location: any;
  binlocation: any;
  racktype: any;
  deliverby: any;
  intime: any;
 




  constructor(private router: Router, private apiService:ApiService,private route:ActivatedRoute ) {
    this.userid=this.route.snapshot.queryParams["userID"]
   }

  
  inboundfn() {
    this.inbound=false;
    this.outbound= true;
    this.moredetails=true;
  }

  outboundfn() {
    this.inbound=true;
    this.outbound= false;
    this.moredetails=true;
  }
  mdetails(){
    this.moredetails=false;
    this.inbound=true;
    this.outbound=true;

  // debugger;
   this.apiService.mdetails(this.AssetId)
   .subscribe((response) => {
     if(response){
       var wareHouse=response[0];
       this.AssetId=wareHouse.assetid;
       this.userid=wareHouse.userid;
     
       this.Targetid=wareHouse.target;
       this.binlocation=wareHouse.binlocation;
       this.intime=wareHouse.intime;
       this.racktype=wareHouse.racktype;
       this.deliverby=wareHouse.deliverby;
       this.location=wareHouse.location;
     }
    }
   );

  }
  backtoOutbound(){
    this.moredetails=true;
    this.inbound=true;
    this.outbound=false;
  }
  
  ngOnInit() {
  }

  inboundAcceptfn() {
    this.inboundAccept=false;
    this.inboundReject=true;

  }

  inboundRejectfn() {
    this.inboundReject=false;
    this.inboundAccept=true;

  }
  createAsset(){
    this.assetCreated=false;
    this.assetTransferred=true;
  }
  public transfer(binlocation,intime){
//debugger;
    var intimestamp =this.intime;
    var seconds=intimestamp.getTime();
    this.apiService.transfer(this.binlocation)
    .subscribe((response) => {
      if(response){
        var iotdata=response[0];
        var endtimestamp=iotdata.endtime;
        }
     }
    );


    this.assetCreated=true;
    this.assetTransferred=false;
  }
  

  public createOutbound(){
    //debugger;
   this.apiService.createOutbound({"assetid":this.AssetId,"userid":this.userid,"lotid":this.Lotid})
   .subscribe((response) => {
     //debugger;
     if(response){
       this.hideAlert=false;
       // var farmer=response[0];
       // this.AssetId=farmer.assetid;
       // this.userid=farmer.userid;
     }
    }
   );
  }
  
  public getwhdetails(AssetIdin,useridin){
    //debugger;
   this.apiService.getwhdetails(AssetIdin,useridin)
   .subscribe((response) => {
     if(response){
       var processingHouse=response[0];
       this.AssetIdin=processingHouse.assetid;
       this.useridin=processingHouse.userid;
      
     }
    }
   );
  }





  public getwhdetailsoutbound(AssetId){
   //debugger;
   this.apiService.getwhdetailsoutbound(AssetId)
   .subscribe((response) => {
     if(response){
       var wareHouse=response[0];
       this.AssetId=wareHouse.assetid;
       this.userid=wareHouse.userid;
       this.Targetid=wareHouse.target;
       this.binlocation=wareHouse.binlocation;
       this.intime=wareHouse.intime;
       this.racktype=wareHouse.racktype;
       this.deliverby=wareHouse.deliverby;
       this.location=wareHouse.location;
     }
    }
   );
  }

}

