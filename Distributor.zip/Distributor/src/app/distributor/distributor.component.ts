import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-distributor',
  templateUrl: './distributor.component.html',
  styleUrls: ['./distributor.component.css']
})
export class DistributorComponent implements OnInit {

  inbound:boolean=false;
  outbound:boolean=true;
  inboundAccept:boolean=true;
  inboundReject:boolean=true;
  moredetails : boolean=true;
  assetCreated:boolean=true;
  assetTransferred:boolean=true;

  constructor() { }

  ngOnInit() {
   
  }

  inboundAcceptfn() {
    this.inboundAccept=false;
    this.inboundReject=true;

  }

  inboundRejectfn() {
    this.inboundReject=false;
    this.inboundAccept=true;

  }

  inboundfn() {
    this.inbound=false;
    this.outbound= true; 
    this.moredetails=true;   
  }

  outboundfn() {
    this.inbound=true;
    this.outbound= false;
     this.moredetails=true;
  }

  mdetails(){
    this.moredetails=false;
    this.inbound=true;
    this.outbound=true;
  }

  backtoOutbound(){
    this.moredetails=true;
    this.inbound=true;
    this.outbound=false;
  }

  createAsset(){
    this.assetCreated=false;
    this.assetTransferred=true;
  }

  public transfer(binlocation,intime){
        this.assetCreated=true;
        this.assetTransferred=false;
      }
}

